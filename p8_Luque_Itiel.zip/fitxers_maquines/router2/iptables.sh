#!/bin/bash

IPT=/sbin/iptables

# Buida (elimina) les regles actuals
$IPT -F # regles amb chain FILTER
$IPT -X # Agrupacions de regles definides per l'usuari. Chain FILTER
$IPT -Z # Comptadors a zero per regles chain FILTER
$IPT -t nat -F # regles amb chain NAT

# POLÍTICA PER DEFECTE DROP
$IPT -P INPUT DROP
$IPT -P OUTPUT DROP
$IPT -P FORWARD DROP

# La pròpia màquina té accés als seus recursos
$IPT -A INPUT -i lo -j ACCEPT
$IPT -A OUTPUT -o lo -j ACCEPT

$IPT -A INPUT -s 127.0.0.1 -d 127.0.0.1 -j ACCEPT
$IPT -A OUTPUT -s 127.0.0.1 -d 127.0.0.1 -j ACCEPT

# Permet actualitzar la data amb protocol NTP
$IPT -A INPUT -p udp --sport 123 -j ACCEPT
$IPT -A OUTPUT -p udp --dport 123 -j ACCEPT

# Permet fer pings
$IPT -A INPUT -p icmp --icmp-type echo-request -j ACCEPT
$IPT -A OUTPUT -p icmp --icmp-type echo-reply -j ACCEPT

$IPT -A FORWARD -p icmp --icmp-type echo-request -j ACCEPT
$IPT -A FORWARD -p icmp --icmp-type echo-reply -j ACCEPT

# Permet sortir a inet fent NAT
$IPT -t nat -A POSTROUTING -o eth-troncal-2 -j MASQUERADE

# Permet SSH a la xarxa interna de proves
$IPT -A INPUT -p tcp -s 192.168.56.0/24 --sport 1024:65535 --dport 22 -m state --state NEW,ESTABLISHED -j ACCEPT
$IPT -A OUTPUT -p tcp -d 192.168.56.0/24 --dport 1024:65535 --sport 22 -m state --state ESTABLISHED -j ACCEPT

# Admins barra lliure
$IPT -A INPUT -s 10.10.3.0/28 -j ACCEPT
$IPT -A OUTPUT -d 10.10.3.0/28 -j ACCEPT

$IPT -A FORWARD -s 10.10.3.0/28 -j ACCEPT
$IPT -A FORWARD -d 10.10.3.0/28 -j ACCEPT

# Router accedir DNS
$IPT -A INPUT -s 10.10.1.4,10.10.1.5 -d 10.10.1.2 -p tcp --sport 53 -j ACCEPT
$IPT -A OUTPUT -d 10.10.1.4,10.10.1.5 -s 10.10.1.2 -p tcp --dport 53 -j ACCEPT

$IPT -A INPUT -s 10.10.1.4,10.10.1.5 -d 10.10.1.2 -p udp --sport 53 -j ACCEPT
$IPT -A OUTPUT -d 10.10.1.4,10.10.1.5 -s 10.10.1.2 -p udp --dport 53 -j ACCEPT

# Router accedir SSH
$IPT -A INPUT -s 10.10.1.4,10.10.1.5 -d 10.10.1.2 -p tcp --sport 22 -m state --state NEW,ESTABLISHED -j ACCEPT
$IPT -A OUTPUT -d 10.10.1.4,10.10.1.5 -s 10.10.1.2 -p tcp --dport 22 -m state --state ESTABLISHED -j ACCEPT

# Servidors interns per xarxa admin cap a inet
$IPT -A FORWARD -s 10.10.3.2 -d 0.0.0.0/0 -p all -m state --state NEW,ESTABLISHED -j ACCEPT
$IPT -A FORWARD -d 10.10.3.2 -s 0.0.0.0/0 -p all -m state --state NEW,ESTABLISHED -j ACCEPT

# Servidors interns per xarxa clients cap a inet
$IPT -A FORWARD -s 10.10.2.2 -d 0.0.0.0/0 -p all -m state --state NEW,ESTABLISHED -j ACCEPT
$IPT -A FORWARD -d 10.10.3.2 -s 0.0.0.0/0 -p all -m state --state NEW,ESTABLISHED -j ACCEPT

# Clients cap a inet
$IPT -A FORWARD -s 10.10.2.0/28 -d 0.0.0.0/0 -p all -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT
$IPT -A FORWARD -d 10.10.2.0/28 -s 0.0.0.0/0 -p all -m state --state ESTABLISHED,RELATED -j ACCEPT

# Clients cap a equips DNS
$IPT -A FORWARD -s 10.10.2.0/28 -d 10.10.1.4,10.10.1.5 -p tcp --dport 53 -j ACCEPT
$IPT -A FORWARD -d 10.10.2.0/28 -s 10.10.1.4,10.10.1.5 -p tcp --sport 53 -j ACCEPT

$IPT -A FORWARD -s 10.10.2.0/28 -d 10.10.1.4,10.10.1.5 -p udp --dport 53 -j ACCEPT
$IPT -A FORWARD -d 10.10.2.0/28 -s 10.10.1.4,10.10.1.5 -p udp --sport 53 -j ACCEPT

# Clients cap a equips SSH
$IPT -A FORWARD -s 10.10.2.0/28 -d 10.10.1.4,10.10.1.5 -p udp --dport 22 -m state --state NEW,ESTABLISHED -j ACCEPT
$IPT -A FORWARD -d 10.10.2.0/28 -s 10.10.1.4,10.10.1.5 -p udp --sport 22 -m state --state ESTABLISHED -j ACCEPT

# Clients cap a NAS
$IPT -A FORWARD -s 10.10.2.0/28 -d 10.10.4.4 -p all -m state --state NEW,ESTABLISHED -j ACCEPT
$IPT -A FORWARD -d 10.10.2.0/28 -s 10.10.4.4 -p all -m state --state ESTABLISHED -j ACCEPT

# Clients cap a qualsevol xarxa
$IPT -A FORWARD -s 10.10.2.0/28 -d 10.10.1.0/28,10.10.2.0/28,10.10.3.0/28,10.10.4.0/28 -j ACCEPT
$IPT -A FORWARD -d 10.10.2.0/28 -s 10.10.1.0/28,10.10.2.0/28,10.10.3.0/28,10.10.4.0/28 -j ACCEPT

# Servidors cap a equips DNS
$IPT -A FORWARD -s 10.10.4.0/28 -d 10.10.1.4,10.10.1.5 -p tcp --dport 53 -j ACCEPT
$IPT -A FORWARD -d 10.10.4.0/28 -s 10.10.1.4,10.10.1.5 -p tcp --sport 53 -j ACCEPT

$IPT -A FORWARD -s 10.10.4.0/28 -d 10.10.1.4,10.10.1.5 -p udp --dport 53 -j ACCEPT
$IPT -A FORWARD -d 10.10.4.0/28 -s 10.10.1.4,10.10.1.5 -p udp --sport 53 -j ACCEPT

# Monitor barra lliure
$IPT -A INPUT -s 10.10.1.11,10.10.2.11,10.10.3.11,10.10.4.11 -j ACCEPT
$IPT -A OUTPUT -d 10.10.1.11,10.10.2.11,10.10.3.11,10.10.4.11 -j ACCEPT

$IPT -A FORWARD -s 10.10.1.11,10.10.2.11,10.10.3.11,10.10.4.11 -j ACCEPT
$IPT -A FORWARD -d 10.10.1.11,10.10.2.11,10.10.3.11,10.10.4.11 -j ACCEPT

# Deixa sortir el paquets interns cap a inet
$IPT -A FORWARD -o eth-troncal-2 -j ACCEPT

# RIPv2 Xarxa DMZ
$IPT -A INPUT -s 10.10.1.1 -d 224.0.0.9 -p udp --dport 520 -j ACCEPT
$IPT -A OUTPUT -s 10.10.1.2 -d 224.0.0.9 -p udp --dport 520 -j ACCEPT

# RIPv2 Xarxa Clients
$IPT -A INPUT -s 10.10.2.2 -d 224.0.0.9 -p udp --dport 520 -j ACCEPT
$IPT -A OUTPUT -s 10.10.2.1 -d 224.0.0.9 -p udp --dport 520 -j ACCEPT

# RIPv2 acceptem també els paquets propis
$IPT -A INPUT -s 10.10.1.2,10.10.2.1 -d 224.0.0.9 -p udp --dport 520 -j ACCEPT
$IPT -A OUTPUT -s 10.10.1.2,10.10.2.1 -d 224.0.0.9 -p udp --dport 520 -j ACCEPT

# IGMP
$IPT -A OUTPUT -s 10.10.1.2,10.10.2.1 -d 224.0.0.22 -j ACCEPT

# Paquet "The All Hosts multicast group addresses all hosts on the same network segment."
$IPT -A INPUT -s 192.168.1.1  -d 224.0.0.1  -j ACCEPT

# DHCP (REGLA ESPECIAL NO NECESSARIA)
$IPT -A INPUT -s 255.255.255.255 -d 0.0.0.0/0 -p udp --sport 68 --dport 67 -j ACCEPT
$IPT -A INPUT -s 0.0.0.0/0 -d 255.255.255.255 -p udp --sport 68 --dport 67 -j ACCEPT
$IPT -A OUTPUT -s 10.10.1.2 -d 255.255.255.255 -p udp --sport 67 --dport 68 -j ACCEPT

# Loguejem tots els paquets que el FW està rebutjant
$IPT -N LOGGING
$IPT -A INPUT -j LOGGING
$IPT -A OUTPUT -j LOGGING
$IPT -A FORWARD -j LOGGING
$IPT -A LOGGING -m limit --limit 1/min -j LOG --log-prefix "IPTables-Dropped: " --log-level 4
$IPT -A LOGGING -j DROP
