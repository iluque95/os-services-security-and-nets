#!/bin/bash

IPT=/sbin/iptables

# Buida (elimina) les regles actuals
$IPT -F # regles amb chain FILTER
$IPT -X # Agrupacions de regles definides per l'usuari. Chain FILTER
$IPT -Z # Comptadors a zero per regles chain FILTER
$IPT -t nat -F # regles amb chain NAT

# POLÍTICA PER DEFECTE DROP
$IPT -P INPUT ACCEPT
$IPT -P OUTPUT ACCEPT
$IPT -P FORWARD ACCEPT

$IPT -t nat -A POSTROUTING -o eth-troncal-1 -j MASQUERADE