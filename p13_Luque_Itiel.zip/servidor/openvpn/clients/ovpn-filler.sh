#!/bin/bash

if [ $# -ne 1 ]; then
 echo "Usage() ovpn-filler.sh <user_certificate>"
 exit 0
fi

cp template.ovpn "$1.ovpn"
echo "key-direction 1" >> "$1.ovpn"
echo "<ca>" >> "$1.ovpn"
sed -n '/BEGIN CERTIFICATE/,/END CERTIFICATE/p' < ../certs/keys/ca.crt >> "$1.ovpn"
echo "</ca>" >> "$1.ovpn"
echo "<cert>" >> "$1.ovpn"
sed -n '/BEGIN CERTIFICATE/,/END CERTIFICATE/p' < ../certs/keys/$1.crt >> "$1.ovpn"
echo "</cert>" >> "$1.ovpn"
echo "<key>" >> "$1.ovpn"
sed -n '/BEGIN PRIVATE KEY/,/END PRIVATE KEY/p' < ../certs/keys/$1.key >> "$1.ovpn"
echo "</key>" >> "$1.ovpn"
echo "<tls-auth>" >> "$1.ovpn"
sed -n '/-----BEGIN OpenVPN Static key V1-----/,/-----BEGIN OpenVPN Static key V1-----/p' < ../certs/keys/ta.key >> "$1.ovpn"
echo "</tls-auth>" >> "$1.ovpn"
